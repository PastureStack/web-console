"use strict";

module.exports = require("core-js-pure/features/array/map");
