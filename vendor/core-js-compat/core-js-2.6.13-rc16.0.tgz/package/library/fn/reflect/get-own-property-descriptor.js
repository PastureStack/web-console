"use strict";

module.exports = require("core-js-pure/features/reflect/get-own-property-descriptor");
