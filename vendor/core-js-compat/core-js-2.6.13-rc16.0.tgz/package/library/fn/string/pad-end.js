"use strict";

module.exports = require("core-js-pure/features/string/pad-end");
