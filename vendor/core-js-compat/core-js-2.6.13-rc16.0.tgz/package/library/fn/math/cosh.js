"use strict";

module.exports = require("core-js-pure/features/math/cosh");
